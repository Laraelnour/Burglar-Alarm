#include "Arduino.h"
#include "Sensor.h"

Sensor::Sensor(){}
void Sensor::initiate(int pin, int ID)
{
    pinMode(pin,INPUT_PULLUP); ///////////////////////////////////////might need changing to INPUT
    _pin=pin;
    _ID=ID;
  
}

bool Sensor::getState()
{
  _state=digitalRead(_pin);
  return _state;
  
}

int Sensor::getID()  ///should there be a function or could we retrieve the variable another way?
{
  return _ID;
}
