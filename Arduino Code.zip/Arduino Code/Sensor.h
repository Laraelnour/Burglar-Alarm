#ifndef Sensor_h
#define Sensor_h
#include "Arduino.h"

class Sensor
{
  public:
    Sensor();
    void initiate (int pin, int ID);
    bool getState();
    int getID();

protected:
    int _pin;
    bool _state;
    int _ID;
    
};

#endif
