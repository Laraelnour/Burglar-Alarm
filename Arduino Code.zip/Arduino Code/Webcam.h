#ifndef Webcam_h
#define Webcam_h
#include "Arduino.h"

class Webcam
{
  public:
    Webcam();
    //add an initiate method?
    bool checkFaceRegistered();
  
};
#endif
