#include "Webcam.h"

Webcam::Webcam(){}

bool Webcam::checkFaceRegistered()
{
  ////////Send command to matlab to begin facial recognition
  // retrieve a HIGH or a LOW from Matlab to determine if face has been recognized

  //(Note: Actually Matlab will only send a 1 if a face is recognized.
  // It will not send a zero.
  //So maybe this code should run for like 20 seconds and if it doesnt recieve
  // a 1 from matlab it should determine the face as unrecognized
  
}
