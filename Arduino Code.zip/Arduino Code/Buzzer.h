#ifndef Buzzer_h
#define Buzzer_h

#include <Arduino.h>
#include "Actuator.h"

class Buzzer:public Actuator
{
  public:
           Buzzer();
           void initiate(int pin, int ID);
           void interruptedRinging(int pin);
           void cutoffBuzzer();
        
  protected:
           int _numberofBeeps;
           int _cutoffTime;
           int _pin;
           bool _state;
           int _ID;
};

#endif
