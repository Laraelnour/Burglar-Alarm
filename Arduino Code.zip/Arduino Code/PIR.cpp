#include "PIR.h"
int motionStateCurrent = LOW;        // current  state of motion sensor's pin
int motionStatePrevious = LOW;       // previous state of motion sensor's pin
int variable=0;

PIR::PIR()
{}

void PIR::initiate(int pin, int ID)
{
     pinMode(pin,INPUT);
    _pin=pin;
    _ID=ID;
}

int PIR::detectMotion(int pin, int led_pin, int buzzer_pin)
{
  _pin=pin;

  motionStatePrevious = motionStateCurrent;            // store old state
  motionStateCurrent  = digitalRead(_pin);  // read new state
 
  if (motionStatePrevious == LOW && motionStateCurrent == HIGH) { // pin state change: LOW -> HIGH
    digitalWrite(led_pin, HIGH);
    //Serial.println("Motion detected!");
    variable=1;
  }
  else if (motionStatePrevious == HIGH && motionStateCurrent == LOW) { // pin state change: HIGH -> LOW
    digitalWrite(led_pin, LOW);
    noTone(buzzer_pin);     // Stop sound...
    variable=0;
  }
  return variable;
}
