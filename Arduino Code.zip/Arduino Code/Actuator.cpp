#include "Arduino.h"
#include "Actuator.h"

Actuator::Actuator(){}

void Actuator::initiate(int pin, int ID) {
  pinMode(pin, OUTPUT);
  _pin = pin;
  _ID = ID;
}

void Actuator::setState(bool state) {
  digitalWrite(_pin,state);
  _state=state;
}

bool Actuator::getState()
{
  return _state;
}

int Actuator::getID() {
  return _ID ;

} 
