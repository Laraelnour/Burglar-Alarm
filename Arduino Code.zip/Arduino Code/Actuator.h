#ifndef Actuator_h
#define Actuator_h
#include <Arduino.h> 


class Actuator
{
  public:
        Actuator();
        void initiate(int pin, int ID);
        void setState(bool state);
        bool getState();
        int getID();
        
  protected:
        bool _state;
        int _pin;
        int _ID;
};

#endif
