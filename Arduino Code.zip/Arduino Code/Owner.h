#ifndef Owner_h
#define Owner_h

#include "Arduino.h"

class Owner{
 
protected:

    int a;

public:

    Owner();
    String PIN;
     String New_PIN;
    int check_pin();
    void change_pin();
     String x="1234";
};

#endif
