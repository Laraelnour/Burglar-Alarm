#include "Owner.h"
#include"Arduino.h"

Owner::Owner(){}


int Owner::check_pin()
{
  Serial.end();
  Serial.begin(9600);
  Serial.flush();
  while(Serial.available()==0);
  {
    PIN=Serial.readStringUntil('\n');
    if(PIN==x)
    {
      Serial.print("31"); //"correct"
      Serial.print('\n');
      a=1;
     }
     else{a=0;}
  }
  return a;
}


void Owner::change_pin()
{
  // Enter new pin
  Serial.end();
  Serial.begin(9600);
  Serial.flush();
   while(Serial.available()==0);
  {  
    New_PIN=Serial.readStringUntil('\n');
    x=New_PIN;    
    // Pin Updated
  }
}
