#ifndef PIR_h
#define PIR_h

#include <Arduino.h>
#include "Sensor.h"

class PIR:public Sensor
{
  public:
    PIR();
    void initiate(int pin, int ID);
    int detectMotion(int pin, int led_pin, int buzzer_pin);
    
};

#endif
