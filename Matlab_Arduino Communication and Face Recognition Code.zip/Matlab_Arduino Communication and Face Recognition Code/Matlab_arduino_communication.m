clc; clear;
arduino = serialport('COM3',9600);
k=0;count=0;
while (k==0)
 %flush(arduino);
%  Text=read(arduino,10,"string")
%  a=strcmp(Text,"Enter PIN:");
dontskip=0;
% write arm state
% write buzzer state
read(arduino,2,'uint8'); %% Needs to read before writing!
read(arduino,1,"char"); %skipping the newline
writeline(arduino,"0"); %telling arduino system is UNarmed
disp(" ");
disp("System Start");
a=read(arduino,2,'uint8');

 if (a==[48,48])   %reading Enter PIN
     PIN = input('Enter Pin: ','s'); %% accepting the 4 digit pin
     writeline(arduino,PIN);  %% sending it to arduino for comparision
     read(arduino,1,"char"); %skipping the newline
     pin = read(arduino,2,'uint8'); % reading a=1 or a=0 (31 or 30 in char)
    
     if (pin==[51,49]) %if pin is correct show menu
         disp('Correct PIN');
        Opt = menu('Chose from below options:',"ARM System","Change Pin","Register faces","Maintanance");
        switch Opt
            case 1 % Arming Systemd
                disp("")
                disp('System armed')
                disp("Unlocking door - Please leave the house")
                writeline(arduino,"1"); %%prompting choosing Arm system option
                pause(2);  %% Time for user to leave
                disp("Locking Door Now in:");
                for q=3:-1:1
                   fprintf('%d...',q);
                   pause(1)
                end
                fprintf('\n Door locked \n');
                disp("Waiting 5 more seconds to activate sensors")
                 pause(5);
                 disp("Sensors start detecting...")

                 
                 loop=1; repeat=1;
                 ccount=0; messages=1;
                 while(loop==1 || repeat==1)
                     read(arduino,1,"char"); %skipping the newline
                     b=read(arduino,2,'uint8');
                     if (b==[48,49])
                         while (messages==1)
                         %buzzer is on here!
                        disp(" ");
                        disp("INTRUDER ALERT!!!!!")
                        disp("Notifying police and user")
                        disp("Recording data")
                        disp("Data sent to police")
                        disp(" ");
                        messages=0;
                         end
                     end
                      read(arduino,1,"char"); %skipping the newline
                    
                     % Giving option of deactivating buzzer through face recognition or PIN:
                     prompt = sprintf('Disable Buzzer through:');
	                 options = questdlg(prompt,'Disabling Buzzer Options','PIN','Face Recognition','PIN');
	                 ChosenOption = find(ismember({'PIN','Face Recognition',},options));

                     if ChosenOption==1
                     writeline(arduino,"1");
                     c=read(arduino,2,'uint8'); %Enter PIN command
                     if (c==[48,48])
                         disp("")
                         PIN = input('Enter Pin: ','s'); %% accepting the 4 digit pin
                         writeline(arduino,PIN);  %% sending it to arduino for comparision
                         read(arduino,1,"char"); %skipping the newline
                         pin = read(arduino,2,'uint8'); % reading a=1 or a=0 (31 or 30 in char)
                        
                         if (pin==[51,49]) %if pin is correct show menu
                            disp('Correct PIN');
                            disp("Turning Buzzer off")
                            loop=0; repeat=0;
    
                         elseif (pin==[51,48]) %incorrect pin
                             disp('Incorrect PIN');
                             ccount=ccount+1;
                             aattempts = 3 - ccount;   
                             fccount = ccount+1;
                             fprintf('number of attemts remaining %d\n',aattempts)
                             if (aattempts == 0)
                                disp(" ")
                                disp('Shutting System down')
                                % Buzzer will beep until cut off time!
                                disp('PLEASE PRESS RUN AGAIN')
                                return;
                            end
                             loop=1;
                         end
                     end

                     elseif ChosenOption==2   %on arduino reads until "enter pin"
                        writeline(arduino,"2");
                        disp("Face recognition chosen") 
                        streamingFaceRecognitionOption=[53 49];
                        save ('filename','streamingFaceRecognitionOption');
                        clear arduino; % disconnecting the arduino stops the buzzer!
                        streamingFaceRecognition;    % I need it to keep toning the buzzer inside
                        load ('filename2.mat','repeat')
                        %disp(" Back to Main script")
                        arduino = serialport('COM3',9600); %need to connect arduino again to this script!
              % need to tell arduino : arm=1, read warning messages, & write option =2
                        read(arduino,2,'uint8'); %% Needs to read before writing!
                        read(arduino,1,"char"); %skipping the newline
                         writeline(arduino,"1"); %telling arduino system is armed
                         s=read(arduino,2,'uint8'); %skipping the warning messages
                         read(arduino,1,"char"); %skipping the newline
                         writeline(arduino,"2"); % writing option=2
                         read(arduino,2,'uint8'); %% skipping printing "h2"
                         read(arduino,1,"char"); %skipping the newline
                        if (repeat==0)
                            writeline(arduino,"1"); % telling arduino that face is right
                        elseif (repeat==1)
                            writeline(arduino,"0"); % telling arduino that face is wrong
                        end

                        loop=0;
                        dontskip=0;
% HUGE ISSUE HERE FROM DISCONNECTING AND RECONNECTING THE ARDUINO!! Must
% find a way to keep buzzer buzzing while detecting face and to tell the
% system (arduino) that it is armed and that the buzzer is on when it reconnects!
                     end
                 end
                                      disp("end loop")


            case 2 % Changing PIN
                 writeline(arduino,"2");
                 PIN = input('Enter Current Pin: ','s'); %% accepting the 4 digit pin
                 writeline(arduino,PIN);  %% sending it to arduino for comparision
                 read(arduino,1,"char"); %skipping the newline
                 read(arduino,1,"char"); %skipping the newline
                 pin = read(arduino,2,'uint8'); % reading a=1 or a=0 (31 or 30 in char)
                 if (pin==[51,49])
                     disp('Correct PIN');
                     read(arduino,1,"char"); %skipping the newline
                     newPIN = input('Enter New Pin: ','s'); %% accepting the 4 digit pin
                     writeline(arduino,newPIN);  %% sending it to arduino for comparision
                     disp("PIN Updated")
                 elseif (pin==[51,48])
                     disp('Incorrect PIN');
                 end
                 count=0;
    
            case 3 % Registering Faces
                disp('Register faces')
                writeline(arduino,"3"); 
                read(arduino,1,'uint8'); % reading the newline to dismiss it
                streamingFaceRecognitionOption=read(arduino,2,'uint8'); % [53 48]
                save ('filename','streamingFaceRecognitionOption');
                clear arduino;
               streamingFaceRecognition;
               disp(" Back to Main script")
               arduino = serialport('COM3',9600); %need to connect arduino again to this script!
               dontskip=1;
               
               
               
            case 4 % Maintenance
                disp('Maintenance')
                %flid = fopen('/Users/usmantahir/Downloads/B_Alarm_epmloy_list.txt','w+t');
                for  Count = 0:1:2
                EID = input('\nEnter Employ ID\n');
                if  (EID == 200184515)
                        disp('Hello Usman');
                end
                if  (EID == 200121299)    
                        disp('Hello Lara');
                end
                if  (EID == 222222222)
                        disp('Hello Arush');
                end
                if  (EID == 333333333)
                        disp('Hello Omer');
                end
                if  (EID == 444444444)
                        disp('Hello Nahla');
                end
                if  (EID == 555555555)
                        disp('Hello Seun');
                end
                if (EID>9999999) && (EID<999999999) && (EID == 200184515)|| (EID == 200121299)|| (EID == 222222222)|| (EID == 333333333)|| (EID == 444444444)||(EID == 555555555)
                    %fprintf(flid,'%d',EID);
                    OPt = menu('Chose from the option below',"Reboot System");
                switch OPt
                    case 1
                        disp('System rebooting')
                        pause(2)
                        disp('PLEASE PRESS RUN AGAIN')
                        return
                end
                
                else 
                disp('Invalid employ ID. Employ ID is 9 digit code on your ID badge')
                attempts = 2 - Count;   
                fcount = Count+1;
                    fprintf('number of attemts remaining %d\n',attempts) 
                end
                end 

if (attempts == 0)
    disp(" ")
    disp('Shutting System down')
    disp('PLEASE PRESS RUN AGAIN')
    return

end
    
       end
    else 
        disp('Incorrect PIN');
        Attempts = 2 - count;   
        count=count+1;
        fprintf('Number of attemts remaining %d\n',Attempts) 

if Attempts==0
     disp('Shutting System down')
     disp('PLEASE PRESS RUN AGAIN')
     return;
end

     end %ending if pin is correct or incorrect
    end
    k=0;
    if dontskip==0
    read(arduino,1,"char"); %skipping the newline
    end
end